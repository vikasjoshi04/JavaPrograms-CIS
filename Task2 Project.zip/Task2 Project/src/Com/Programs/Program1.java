package Com.Programs;

/* Task-2
	1. Write a java program to achieve Polymorphism ?
*/

class Overloading {
	
	void area(int r) {
		
		System.out.println("Area of Circle :"+(3.14*r*r));
	}
	
	void area(int l, int b) {
		System.out.println("Area of Rectangle :"+ (l*b));
	}
	
	void area(double l, int b) {
		System.out.println("Area of Rectangle :"+ (l*b));
	}
	
	void area(int l, double b) {
		System.out.println("Area of Rectangle :"+ (l*b));
	}
	
	void show() {
		System.out.println("Parent's show()"); 
	}
		
}

class Overriding extends Overloading {
	
	
	void area(double l, double b)
	{
	  System.out.println("Area of Rectangle in child class : "+ (l*b)); 
	}
	
	void show() {
		System.out.println("Child's show()"); 
	}
}

public class Program1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Overloading overload  = new Overloading();
		
		System.out.println("Function Overloading :");
		overload.area(5);
		overload.area(5, 2);
		overload.area(2.5, 5);
		overload.area(10,5.2);
		
		System.out.println("Function Overriding :");
		
		Overloading overriding = new Overriding();
		overriding.show(); // Run Time POLYMORPHISM
		
		Overriding overriding2 = new Overriding();
		overriding2.area(5.5,3.3);
		
	}

}



