package Com.Programs;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/*
 *  10. Do following things :
    i. Create customer.txt file with following values id, name, age, address,
       date of birth. values should be comma separated.
    ii. Write a logic to read customer.txt file.
    iii. Write a logic to create create JDBC connection and save all the values in database.

 */

public class Program10 {
	
	static String[] strAry;
	
	public static void writeInFile() throws IOException {
		String str = "1,Vikas Joshi,23,Indore";
		
		FileWriter fw = new FileWriter("customer.txt");
		
		for(int i=0 ; i< str.length(); i++) {
			fw.write(str.charAt(i));
		}
		System.out.println("Writing Successful");
		fw.close();
	}
	
	public static void readFromFile() throws IOException {
		
		int ch;
		String str="";
		FileReader fr=null; 
        try
        { 
            fr = new FileReader("customer.txt"); 
        } 
        catch (FileNotFoundException fe) 
        { 
            System.out.println("File not found"); 
        } 
		
		while((ch=fr.read())!=-1) {
			str +=(char)ch;
		}
		System.out.println(str);
		
		strAry = str.trim().split(",");
		
		for (String string : strAry) {
			
			System.out.println(string);
		}
		
		fr.close();
	}
	
	private static void saveValuesinDB() {
		
		PreparedStatement pstm = null;
		Connection con = null;
		int id = Integer.parseInt(strAry[0]);
		String name = strAry[1];
		int age = Integer.parseInt(strAry[2]);
		String address = strAry[3];
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankingsystem","root","root");
			
			pstm = con.prepareStatement("insert into customer(id,name,age,address) values(?,?,?,?)");
			pstm.setInt(1, id);
			pstm.setString(2, name);
			pstm.setInt(3, age);
			pstm.setString(4, address);
			
			int i = pstm.executeUpdate();
			if (i > 0) {
				System.out.println("Customer Details Added SuccessFully");
				
			} else {
				System.out.println("Customer Details Failed");
				
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				pstm.close();
				con.close();
				
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		
	}

	public static void main(String []args) throws IOException {
		
		writeInFile();
		
		readFromFile();
		
		saveValuesinDB();
		
	}

	
}
