package Com.Programs;

/*	Task-2
  	2. Do following things  :
    i. Create Employee class with following fields id, name, age, address, date of birth.
    ii. Set these fields values by using setter and construct.
    iii. Print values of employee properties on console.
*/
class Employee{
	private int id;
	private String name;
	private int age;
	private String address;
	private String dob;
	
	public Employee(int id, String name, int age, String address, String dob) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.address = address;
		this.dob = dob;
	}
	
	public Employee() {
		
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	
	public void showEmployee() {
		System.out.println("Employee Details :");
		System.out.println("Employee Id :"+id);
		System.out.println("Employee Name : "+name);
		System.out.println("Employee Age :"+age);
		System.out.println("Employee Address :"+address);
		System.out.println("Employee D.O.B :"+dob+"\n");
	}
	
	
}

public class Program2 {
	
	public static void main(String []args) {
		
		Employee emp1 = new Employee(1, "vikas", 23 , "Indore", "19/03/1996");
		emp1.showEmployee();
		
		Employee emp2 = new Employee();
		
		emp2.setId(2);
		emp2.setName("Ashish");
		emp2.setAge(23);
		emp2.setAddress("Ahmedabad");
		emp2.setDob("25/08/1996");
		
		emp2.showEmployee();
	}
}
