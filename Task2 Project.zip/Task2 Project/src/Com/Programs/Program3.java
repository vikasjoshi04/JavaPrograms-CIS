package Com.Programs;

/* Task 2
 * 3. Write a program to create immutable class  ?
 */

// immutable class
final class AdharCard{
	
	final int adharNo;
	final String userName;
	final String userAddress;
	final String dob;
	final String mail;

	public AdharCard(int adharNo, String userName, String userAddress, String dob, String mail) {

		this.adharNo = adharNo;
		this.userName = userName;
		this.userAddress = userAddress;
		this.dob = dob;
		this.mail = mail;
	}

	public int getAdharNo() {
		return adharNo;
	}

	public String getUserName() {
		return userName;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public String getDob() {
		return dob;
	}

	public String getMail() {
		return mail;
	}

}

public class Program3 {
	
	public static void main(String[] args) {
		
		AdharCard user1 = new AdharCard(1234567890, "abc", "Indore", "12/1/1996", "abc2gmail.com");
		
		System.out.println(user1.getAdharNo());
		System.out.println(user1.getUserName());
		System.out.println(user1.getUserAddress());
		System.out.println(user1.getDob());
		System.out.println(user1.getMail());
	
		//user1.adharNo = 2323; This will give an Error
		
	
	}
}
