package Com.Programs;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/*
 * 	4. Do following things  :
    i. Write a program to create map of integer and string.
    ii. Add five entry in map.
    iii. Iterate map and print values on console.
 */


public class Program4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Map map = new HashMap();
		 Map map=new HashMap();  
		 
		 map.put(101,"Java");
		 map.put(102,"Operating System");
		 map.put(103,"Python");
		 map.put(104,"ROR");
		 map.put(105,"Angular");
		 
		 Set s = map.entrySet();
		 
		 Iterator iter = s.iterator();
	
		 while(iter.hasNext()) {
			 
			 Map.Entry entry = (Map.Entry)iter.next();
			 System.out.println("Key :"+entry.getKey()+" Value :"+entry.getValue());
		 }
	}

}
