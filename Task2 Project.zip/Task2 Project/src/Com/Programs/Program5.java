package Com.Programs;
/*
 * 5. Create a custom exception for user not found ?
 */

class MyException extends Exception {

	public MyException(String msg) {
		super(msg);
	}

}

public class Program5 {

	public static void findUser(String name) throws MyException {

		if(name.equalsIgnoreCase("Vikas")) {
			System.out.println("User Found Successfully");
		} else {
			throw new MyException("User Not Found");
		}
	}

	public static void main(String[] args) {

		try {

			Program5.findUser("abc"); // It will throw an User Defined Exception With a Custom Message
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
