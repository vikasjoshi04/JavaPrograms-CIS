package Com.Programs;
/*
 * 6. Write a program to create custom thread by using thread class and runnable interface ?
 */

class MyThread extends Thread {

	public void run() {

		for (int i = 0; i < 5; i++) {
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("I am in Thread ");
		}

	}
}

class MyThread1 implements Runnable {

	@Override
	public void run() {
		for (int i = 0; i < 5; i++) {
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("I am in Runnable");
		}
	}

}

public class Program6 {

	public static void main(String[] args) {

		MyThread myTh = new MyThread();
		myTh.start();

		MyThread1 myThread1 = new MyThread1();
		Thread t = new Thread(myThread1);
		t.start();
	}

}
