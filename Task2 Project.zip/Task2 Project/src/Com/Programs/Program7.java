package Com.Programs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/*
 * 7. Do following things :
    i.  Create Student class with following fields id, name, age, address, date of birth.
    ii. Create List of Student and add 4-5 student object in the list.
    iii.Perform ascending sorting on list of student object and print all the student object 
    	properties on console.
 */

class Student implements Comparable {
	int id;
	String name;
	int age;
	String address;
	String dob;
	
	public Student(int id, String name, int age, String address, String dob) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.address = address;
		this.dob = dob;
	}

	
	
	public int getId() {
		return id;
	}


	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age + ", address=" + address + ", dob=" + dob + "]";
	}

	@Override
	public int compareTo(Object arg0) {
		
		Student s = (Student)arg0;
		int i = this.getId();
		int j = s.getId();
		
		Integer iobj = i;
		Integer jobj = j;
		
		return iobj.compareTo(jobj);
	}
	
	
}

public class Program7 {
	
	public static void main(String []args) {
		
		Student s1 = new Student(5,"Akash",23,"Indore","12/03/1996");
		Student s2 = new Student(1,"Vikas",24,"Indore","19/03/1996");
		Student s3 = new Student(4,"Mahendra",21,"Indore","12/03/1996");
		Student s4 = new Student(2,"Ravindra",24,"Indore","30/08/1995");
		Student s5 = new Student(3,"Surjeet",23,"Indore","12/03/1996");
		
		
		 List<Student> l1 = new ArrayList<Student>();
		 
		 l1.add(s1);
		 l1.add(s2);
		 l1.add(s3);
		 l1.add(s4);
		 l1.add(s5);
		 
		 System.out.println(l1);
		 
		 Collections.sort(l1);
		 
		 System.out.println(l1);
		 
		
	}
}
