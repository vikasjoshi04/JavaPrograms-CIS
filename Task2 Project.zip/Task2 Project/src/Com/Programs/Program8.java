package Com.Programs;

import java.util.ArrayList; 
import java.util.Arrays; 
import java.util.List; 
import java.util.stream.*; 
/*
 * Write a logic to Convert following list of list [1, 2, [3,4], 5, 6, [7,8,9], 10 ]
 *  into single list like [1,2,3,4,5,6,7,8,9,10].
 */
public class Program8 {
	
	 public static <T> Stream<T> getFlatList(List<List<T> > lists) 
	    { 
	  
	        // Create an empty list to collect the stream 
	        List<T> finalList = new ArrayList<>(); 
	  
	        for (List<T> list : lists) { 
	            list.stream() 
	                .forEach(finalList::add); 
	        } 
	  
	        // Convert the list into Stream and return it 
	        return finalList.stream(); 
	    } 
	
	public static void main(String []args) {
		
		List<Integer> a = Arrays.asList(1, 2); 
        List<Integer> b = Arrays.asList(3, 4);
        List<Integer> c = Arrays.asList(5, 6); 
        List<Integer> d = Arrays.asList(7, 8, 9);
        List<Integer> e = Arrays.asList(10);
  
        List<List<Integer> > arr = new ArrayList<List<Integer> >(); 
        arr.add(a); 
        arr.add(b); 
        arr.add(c);
        arr.add(d);
        arr.add(e);
        
        System.out.println(arr);
        
        List<Integer> flatList = new ArrayList<Integer>(); 
        flatList = getFlatList(arr) 
                       .collect(Collectors.toList()); 
  
        System.out.println(flatList); 
	}
}
