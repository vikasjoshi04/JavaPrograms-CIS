package Com.Programs;
/*
 * 9. Write program for call by value and call by reference in java ?
 */

class Increment {
	int x;
}

public class Program9 {
	public static void main(String []args) {
		
		int x = 10;
		
		System.out.println("Call by Value :");
		System.out.println("Value of x Before Incrementing :"+x);
		callByValue(x);
		System.out.println("Value of x After Incrementing :"+x);
		
		Increment i = new Increment();
		i.x = 10;
		System.out.println("\nCall by Reference :"); 
		System.out.println("Value of x Before Incrementing :"+i.x);
		callByRef(i); // Java does not support call by Reference, 
		              //but can achieve this using Reference type value. 
		System.out.println("Value of x After Incrementing :"+i.x);
		
	}
	
	public static void callByValue(int x) {
		x = x+ 10;
	}
	
	public static void callByRef(Increment no) {
		no.x = no.x + 10;
	}
}
